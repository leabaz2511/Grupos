class AddColumnToActivity < ActiveRecord::Migration
  def change
    add_column :activities, :exclusiveness, :boolean
  end
end
