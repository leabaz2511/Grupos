class AddGroupToAdmissionRequest < ActiveRecord::Migration
  def change
    add_reference :admission_requests, :group, index: true, foreign_key: true
  end
end
