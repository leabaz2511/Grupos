class CreateAdmissionRequests < ActiveRecord::Migration
  def change
    create_table :admission_requests do |t|
      t.date :request_date

      t.timestamps null: false
    end
  end
end
