class CreateActivityMembers < ActiveRecord::Migration
  def change
    create_table :activity_members do |t|
      t.boolean :guest

      t.timestamps null: false
    end
  end
end
