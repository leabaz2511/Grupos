class CreateStateStudies < ActiveRecord::Migration
  def change
    create_table :state_studies do |t|
      t.string :state

      t.timestamps null: false
    end
  end
end
