class AddCourseToBibleStudy < ActiveRecord::Migration
  def change
    add_reference :bible_studies, :course, index: true, foreign_key: true
  end
end
