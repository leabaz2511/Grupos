class CreateActivities < ActiveRecord::Migration
  def change
    create_table :activities do |t|
      t.string :name
      t.date :start_date
      t.date :completion_date
      t.time :start_time
      t.time :completion_time
      t.string :place
      t.integer :quota
      t.text :description

      t.timestamps null: false
    end
  end
end
