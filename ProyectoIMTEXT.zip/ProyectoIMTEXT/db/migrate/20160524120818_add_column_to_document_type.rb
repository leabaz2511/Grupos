class AddColumnToDocumentType < ActiveRecord::Migration
  def change
    add_column :document_types, :doc_type, :string
  end
end
