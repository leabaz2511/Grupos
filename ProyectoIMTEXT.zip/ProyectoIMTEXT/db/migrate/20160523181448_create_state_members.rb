class CreateStateMembers < ActiveRecord::Migration
  def change
    create_table :state_members do |t|
      t.string :state

      t.timestamps null: false
    end
  end
end
