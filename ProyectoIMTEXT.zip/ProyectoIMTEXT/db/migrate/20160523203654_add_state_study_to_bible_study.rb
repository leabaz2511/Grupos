class AddStateStudyToBibleStudy < ActiveRecord::Migration
  def change
    add_reference :bible_studies, :state_study, index: true, foreign_key: true
  end
end
