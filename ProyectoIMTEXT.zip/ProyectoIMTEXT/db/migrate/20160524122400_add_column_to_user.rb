class AddColumnToUser < ActiveRecord::Migration
  def change
    add_column :users, :alumn, :boolean
  end
end
