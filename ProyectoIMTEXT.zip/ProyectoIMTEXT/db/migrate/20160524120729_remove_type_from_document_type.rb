class RemoveTypeFromDocumentType < ActiveRecord::Migration
  def change
    remove_column :document_types, :type, :string
  end
end
