class AddColumnoToBibleStudy < ActiveRecord::Migration
  def change
    add_column :bible_studies, :first_name, :string
    add_column :bible_studies, :last_name, :string
    add_column :bible_studies, :address, :string
    add_column :bible_studies, :email, :string
    add_column :bible_studies, :telephone, :integer
    add_column :bible_studies, :locality, :string
  end
end
