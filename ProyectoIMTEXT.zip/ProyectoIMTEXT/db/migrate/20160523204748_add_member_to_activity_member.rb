class AddMemberToActivityMember < ActiveRecord::Migration
  def change
    add_reference :activity_members, :member, index: true, foreign_key: true
  end
end
