class AddActivityToActivityMember < ActiveRecord::Migration
  def change
    add_reference :activity_members, :activity, index: true, foreign_key: true
  end
end
