class AddMemberToBibleStudy < ActiveRecord::Migration
  def change
    add_reference :bible_studies, :member, index: true, foreign_key: true
  end
end
