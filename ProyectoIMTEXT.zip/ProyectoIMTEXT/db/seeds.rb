# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)
DocumentType.delete_all
StateStudy.delete_all
Members.delete_all
Roles.delete_all
StateMember.delete_all
Groups.delete_all
Users.delete_all


DocumentType.create!(:doc_type => 'DU')
DocumentType.create!(:doc_type => 'PA')
DocumentType.create!(:doc_type => 'LC')
DocumentType.create!(:doc_type => 'LE')

StateStudy.create!(:state => 'Finalizado')
StateStudy.create!(:state => 'En curso')
StateStudy.create!(:state => 'Abandonado')
StateStudy.create!(:state => 'Pendiente')

Role.create!(:role => 'Administrador')
Role.create!(:role => 'Director')
Role.create!(:role => 'Regular')

StateMember.create!(:state => 'Activo')
StateMember.create!(:state => 'Inactivo')
StateMember.create!(:state => 'Pendiente')

Users.create!(:first_name => 'Usuario', :last_name => 'Administrador', :document_type_id => 1, :dni => 11111111, :email => 'inis@uap.edu.ar', :password => '123456789', :password_confirmation => '123456789', :alumn => false)


Members.create!(:date => '01/01/2015', :user_id => 1, :role_id => 1,:state_member_id => 1, :group_id => nil)