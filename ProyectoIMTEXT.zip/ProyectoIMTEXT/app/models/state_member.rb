class StateMember < ActiveRecord::Base
	has_many :members

	before_validation :strip_whitespace, :only => [:state]
	validates_format_of :state, :with => /^[[:alpha:]\s'\--]*$/u, :multiline => true
    validates :state, length: { minimum: 2 }
    validates :state, length: { maximum: 30 }
	validates :state, :presence => true
end
