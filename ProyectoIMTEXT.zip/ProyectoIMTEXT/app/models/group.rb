class Group < ActiveRecord::Base
	has_many :admission_requests
	has_many :members
end
