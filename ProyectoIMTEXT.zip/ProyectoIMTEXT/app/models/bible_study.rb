class BibleStudy < ActiveRecord::Base
	belongs_to :course
	belongs_to :state_study
	belongs_to :member



    before_validation :strip_whitespace, :only => [:first_name, :last_name, :address, :locality]
    validates :course_id, :bible_student_id, :study_state_id, :presence => true
    validates :last_name, :name, :address, :presence => true
    validates :calle, :presence => true
    validates :telefono, :numericality => true
    validates_format_of :first_name, :with => /^[[:alpha:]\s'\--]*$/u, :multiline => true
    validates :first_name, length: { minimum: 2 }
    validates :first_name, length: { maximum: 70 }
    validates_format_of :last_name, :with => /^[[:alpha:]\s'\--]*$/u, :multiline => true
    validates :apellido, length: { minimum: 2 }
    validates :apellido, length: { maximum: 70 }
    validates_format_of :address, :with => /^[[:alpha:][0-9]\s'\--]*$/u, :multiline => true
    validates :address, length: { minimum: 2 }
    validates :address, length: { maximum: 70 }
    validates_format_of :locality, :with => /^[[:alpha:]\s'\--]*$/u, :multiline => true
    validates :locality, length: { minimum: 2 }
    validates :locality, length: { maximum: 70 }

    def name_and_surname
		"#{first_name} #{last_name}"		
	end
end
