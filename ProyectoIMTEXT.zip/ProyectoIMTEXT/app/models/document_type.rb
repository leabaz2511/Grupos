class DocumentType < ActiveRecord::Base
	has_many :users

	before_validation :strip_whitespace, :only => [:type]
	validates_format_of :type, :with => /^[[:alpha:]\s'\--]*$/u, :multiline => true
    validates :type, length: { minimum: 2 }
    validates :type, length: { maximum: 30 }
	validates :type, :presence => true
end
