class ActivityMember < ActiveRecord::Base
	belongs_to :member 
	belongs_to :activity

	def tipo
		if guest == true
			"Visitante"
		elsif guest == false 
			"Miembro"
		end
	end
end
