class Resource < ActiveRecord::Base
end
