class Role < ActiveRecord::Base
	has_many :members


	before_validation :strip_whitespace, :only => [:role]
	validates_format_of :role, :with => /^[[:alpha:]\s'\--]*$/u, :multiline => true
    validates :role, length: { minimum: 2 }
    validates :role, length: { maximum: 30 }
	validates :role, :presence => true
end
