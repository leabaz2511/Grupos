class Member < ActiveRecord::Base
	belongs_to :user
	belongs_to :group, optional: true
	has_many :bible_studies
	belongs_to :role
	belongs_to :state_member

	
end
