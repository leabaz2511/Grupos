class Activity < ActiveRecord::Base
	belongs_to :group
	has_many :activity_members


	#before_validation :strip_whitespace, :only => [:name, :place, :description]

	validates_format_of :name, :with => /^[[:alpha:]\s'\--]*$/u, :multiline => true
	validates :name, length: { minimum: 2 }
	validates :name, length: { maximum: 70 }
	 
	validates_format_of :description, :with => /^[[:alpha:]\s'\--]*$/u, :multiline => true
	 
	validates_format_of :place, :with => /^[[:alpha:][0-9]\s'\--]*$/u, :multiline => true
	validates :place, length: { minimum: 2 }
	validates :place, length: { maximum: 70 }
	 
	validates :group_id, :name, :start_date, :completion_date, :place, :description, :presence => true

	def exclusividad
		if exclusiviness == true
			"Si"
		elsif exclusiviness == false 
			"No"
		end
	end

end