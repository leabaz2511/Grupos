class User < ActiveRecord::Base
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :trackable, :validatable

	has_many :admission_requests
	has_many :members
	belongs_to :document_type, optional: true


	before_validation :strip_whitespace, :only => [:first_name, :last_name, :address, :email]

 	has_attached_file :avatar, :styles => { :medium => "300x300>", :thumb => "100x100>" }, :url => "/:user/:attachment/:id/:style_:filename"
  validates_attachment_content_type :avatar, :content_type => /\Aimage\/.*\Z/

  validates :email, :first_name, :last_name, :document_type_id, :dni, :presence => true
  validates :email, :uniqueness => true
  validates :telephone, :numericality => true
  validates_format_of :first_nale, :with => /^[[:alpha:]\s'\--]*$/u, :multiline => true
  validates :first_name, length: { minimum: 2 }
  validates :first_name, length: { maximum: 70 }
  validates_format_of :last_name, :with => /^[[:alpha:]\s'\--]*$/u, :multiline => true
  validates :last_name, length: { minimum: 2 }
  validates :last_name, length: { maximum: 70 }
  validates_format_of :address, :with => /^[[:alpha:][0-9]\s'\--]*$/u, :multiline => true
  validates :address, length: { minimum: 2 }
  validates :address, length: { maximum: 70 }
  validates_format_of :dni, :with => /\A[-a-zA-Z0-9]*\z/i
 	validates :nro_alumn, :presence => true, :if => :check_alumn?
  #validates_confirmation_of :password, :message => "la contraseña debe ser igual"
  #validates_presence_of :password_confirmation, :if => :password_changed?
  #validates :password_confirmation, :presence => true
  #validates :password, :confirmation => true
  validates :password_confirmation, :password, :presence => true




	def name_and_surname
		"#{first_name} #{last_name}"		
	end
end

