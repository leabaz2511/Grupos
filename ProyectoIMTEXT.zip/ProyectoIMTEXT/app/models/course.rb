class Course < ActiveRecord::Base
	has_many :bible_studies

	before_validation :strip_whitespace, :only => [:name]
	validates_format_of :name, :with => /^[[:alpha:]\s'\--]*$/u, :multiline => true
    validates :name, length: { minimum: 2 }
    validates :name, length: { maximum: 70 }
	validates :name, :presence => true
end
