class AdmissionRequestsController < ApplicationController
  before_action :set_admission_request, only: [:show, :edit, :update, :destroy]
  before_action :authenticate_user!


  # GET /admission_requests
  # GET /admission_requests.json
  def index
    @admission_requests = AdmissionRequest.all
  end

  # GET /admission_requests/1
  # GET /admission_requests/1.json
  def show
  end

  def accept
    @member = Member.new
    @admission_request = AdmissionRequest.find(params[:id])
    @member.user_id = @admission_request.user_id
    @member.group_id = @admission_request.group_id
    @member.state_member_id = 1 #activo
    @member.role_id = 3 #regular
    @member.date = Date.current()
    @member.save
    #redirect_to admission_requests_path
  end

  # GET /admission_requests/new
  def new
    @admission_request = AdmissionRequest.new
  end

  # GET /admission_requests/1/edit
  def edit
  end

  # POST /admission_requests
  # POST /admission_requests.json
  def create
    @admission_request = AdmissionRequest.new(admission_request_params)
    respond_to do |format|
      if @admission_request.save
        format.html { redirect_to admission_requests_path, notice: 'Admission request was successfully created.' }
        format.json { render :index, status: :created, location: @admission_request }
      else
        format.html { render :new }
        format.json { render json: @admission_request.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /admission_requests/1
  # PATCH/PUT /admission_requests/1.json
  def update
    respond_to do |format|
      if @admission_request.update(admission_request_params)
        format.html { redirect_to admission_requests_path, notice: 'Admission request was successfully updated.' }
        format.json { render :index, status: :ok, location: @admission_request }
      else
        format.html { render :edit }
        format.json { render json: @admission_request.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /admission_requests/1
  # DELETE /admission_requests/1.json
  def destroy
    @admission_request.destroy
    respond_to do |format|
      format.html { redirect_to admission_requests_url, notice: 'Admission request was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_admission_request
      @admission_request = AdmissionRequest.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def admission_request_params
      params.require(:admission_request).permit(:request_date, :user_id, :group_id)
    end
end
