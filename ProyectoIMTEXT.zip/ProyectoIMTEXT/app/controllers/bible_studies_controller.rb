class BibleStudiesController < ApplicationController
  before_action :set_bible_study, only: [:show, :edit, :update, :destroy]
  before_action :authenticate_user!
  # GET /bible_studies
  # GET /bible_studies.json
  def index
    @bible_studies = BibleStudy.all
    @member = Member.where(:user_id => current_user.id).first #se usa para identificar el rol
    @multi_member = Member.where(:user_id => current_user.id) #si el usuario pertenece a varios grupos
    if (@member.role.role == 'Regular')
      @list_studies = [] #lista donde se guardaran los estudios biblicos que se veran
      @multi_member.each do |mm|
        unless (mm.state_member.state == 'Inactivo') #sólo miembros activos de los grupos pueden ver los estudios biblicos
          @bible_studies.each do |bs|
            if (bs.member_id == mm.id)
              @list_studies = BibleStudy.where(:id => bs.id)
            end
          end
        end
      end
    elsif (@member.role.role == 'Director')
      @bible_studies.each do |a|
        if (a.group_id == @member.group_id)
          @list_studies = BibleStudy.where(:id => bs.id)
        end
      end
    end
  end

  # GET /bible_studies/1
  # GET /bible_studies/1.json
  def show
  end

  # GET /bible_studies/new
  def new
    @bible_study = BibleStudy.new
  end

  # GET /bible_studies/1/edit
  def edit
  end

  # POST /bible_studies
  # POST /bible_studies.json
  def create
    @bible_study = BibleStudy.new(bible_study_params)

    respond_to do |format|
      if @bible_study.save
        format.html { redirect_to bible_studies_path, notice: 'Bible study was successfully created.' }
        format.json { render :index, status: :created, location: @bible_study }
      else
        format.html { render :new }
        format.json { render json: @bible_study.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /bible_studies/1
  # PATCH/PUT /bible_studies/1.json
  def update
    respond_to do |format|
      if @bible_study.update(bible_study_params)
        format.html { redirect_to bible_studies_path, notice: 'Bible study was successfully updated.' }
        format.json { render :index, status: :ok, location: @bible_study }
      else
        format.html { render :edit }
        format.json { render json: @bible_study.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /bible_studies/1
  # DELETE /bible_studies/1.json
  def destroy
    @bible_study.destroy
    respond_to do |format|
      format.html { redirect_to bible_studies_url, notice: 'Bible study was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_bible_study
      @bible_study = BibleStudy.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def bible_study_params
      params.require(:bible_study).permit(:start_date, :course_id, :state_study_id, :member_id, :course_id, :first_name, :last_name, :address, :telephone, :email, :locality)
    end
end
