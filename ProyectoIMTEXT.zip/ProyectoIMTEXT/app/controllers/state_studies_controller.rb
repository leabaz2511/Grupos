class StateStudiesController < ApplicationController
  before_action :set_state_study, only: [:show, :edit, :update, :destroy]
  before_action :authenticate_user!
  # GET /state_studies
  # GET /state_studies.json
  def index
    @state_studies = StateStudy.all
  end

  # GET /state_studies/1
  # GET /state_studies/1.json
  def show
  end

  # GET /state_studies/new
  def new
    @state_study = StateStudy.new
  end

  # GET /state_studies/1/edit
  def edit
  end

  # POST /state_studies
  # POST /state_studies.json
  def create
    @state_study = StateStudy.new(state_study_params)

    respond_to do |format|
      if @state_study.save
        format.html { redirect_to state_studies_path, notice: 'State study was successfully created.' }
        format.json { render :index, status: :created, location: @state_study }
      else
        format.html { render :new }
        format.json { render json: @state_study.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /state_studies/1
  # PATCH/PUT /state_studies/1.json
  def update
    respond_to do |format|
      if @state_study.update(state_study_params)
        format.html { redirect_to state_studies_path, notice: 'State study was successfully updated.' }
        format.json { render :index, status: :ok, location: @state_study }
      else
        format.html { render :edit }
        format.json { render json: @state_study.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /state_studies/1
  # DELETE /state_studies/1.json
  def destroy
    @state_study.destroy
    respond_to do |format|
      format.html { redirect_to state_studies_url, notice: 'State study was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_state_study
      @state_study = StateStudy.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def state_study_params
      params.require(:state_study).permit(:state)
    end
end
