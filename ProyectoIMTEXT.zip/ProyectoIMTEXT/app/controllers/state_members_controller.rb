class StateMembersController < ApplicationController
  before_action :set_state_member, only: [:show, :edit, :update, :destroy]
  before_action :authenticate_user!
  # GET /state_members
  # GET /state_members.json
  def index
    @state_members = StateMember.all
  end

  # GET /state_members/1
  # GET /state_members/1.json
  def show
  end

  # GET /state_members/new
  def new
    @state_member = StateMember.new
  end

  # GET /state_members/1/edit
  def edit
  end

  # POST /state_members
  # POST /state_members.json
  def create
    @state_member = StateMember.new(state_member_params)

    respond_to do |format|
      if @state_member.save
        format.html { redirect_to state_members_path, notice: 'State member was successfully created.' }
        format.json { render :index, status: :created, location: @state_member }
      else
        format.html { render :new }
        format.json { render json: @state_member.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /state_members/1
  # PATCH/PUT /state_members/1.json
  def update
    respond_to do |format|
      if @state_member.update(state_member_params)
        format.html { redirect_to state_members_path, notice: 'State member was successfully updated.' }
        format.json { render :index, status: :ok, location: @state_member }
      else
        format.html { render :edit }
        format.json { render json: @state_member.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /state_members/1
  # DELETE /state_members/1.json
  def destroy
    @state_member.destroy
    respond_to do |format|
      format.html { redirect_to state_members_url, notice: 'State member was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_state_member
      @state_member = StateMember.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def state_member_params
      params.require(:state_member).permit(:state)
    end
end
