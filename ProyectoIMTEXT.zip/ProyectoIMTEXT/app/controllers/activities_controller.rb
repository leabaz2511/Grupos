class ActivitiesController < ApplicationController
  before_action :set_activity, only: [:show, :edit, :update, :destroy]
  before_action :authenticate_user!
  # GET /activities
  # GET /activities.json
  def index

    @activities = Activity.all
    @member = Member.where(:user_id => current_user.id).first #se usa para identificar el rol
    @multi_member = Member.where(:user_id => current_user.id) #si el usuario pertenece a varios grupos
    if (@member.role.role == 'Regular')
      @list_activity = [] #lista donde se guardaran las actividades que se veran
      @multi_member.each do |mm|
        unless (mm.state_member.state == 'Inactivo') #sólo miembros activos de los grupos pueden ver las actividades
          @activities.each do |a|
            if (a.group_id == mm.group_id)
              @list_activity << Activity.where(:id => a.id)
            elsif (a.exclusiveness == false)  #si una actividad, a la que no pertenece el usuario, no es exclusiva entonces tambien se agrega a la lista
              @list_activity = Activity.where(:id => a.id)
            end
          end
        end
      end
    elsif (@member.role.role == 'Director')
      @activities.each do |a|
        if (a.group_id == @member.group_id)
          @list_activity = Activity.where(:id => a.id)
        elsif (a.exclusiveness == false) #si una actividad, a la que no pertenece el usuario, no es exclusiva entonces tambien se agrega a la lista
          @list_activity = Activity.where(:id => a.id)
        end
      end
    end
  end

  # GET /activities/1
  # GET /activities/1.json
  def show
  end

  def enroll
    @activity_member = ActivityMember.new
    @activity = Activity.find(params[:id])
    @member = Member.where(:user_id => current_user.id)
    @activity_member.member_id = @member.id
    @activity_member.activity_id = @activity.id
    @activity_member.save
    redirect_to activities_path
  end

  def resign
    @activity = Activity.find(params[:id])
    @activity_member = ActivityMember.where("member_id = ? and activity_id = ?", current_user.id, @activity.id).first
    @activity_member.destroy
    redirect_to activities_path
  end

  # GET /activities/new
  def new
    @activity = Activity.new
  end

  # GET /activities/1/edit
  def edit
  end

  # POST /activities
  # POST /activities.json
  def create
    @activity = Activity.new(activity_params)

    respond_to do |format|
      if @activity.save
        format.html { redirect_to activities_path, notice: 'Activity was successfully created.' }
        format.json { render :index, status: :created, location: @activity }
      else
        format.html { render :new }
        format.json { render json: @activity.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /activities/1
  # PATCH/PUT /activities/1.json
  def update
    respond_to do |format|
      if @activity.update(activity_params)
        format.html { redirect_to activities_path, notice: 'Activity was successfully updated.' }
        format.json { render :index, status: :ok, location: @activity }
      else
        format.html { render :edit }
        format.json { render json: @activity.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /activities/1
  # DELETE /activities/1.json
  def destroy
    @activity.destroy
    respond_to do |format|
      format.html { redirect_to activities_url, notice: 'Activity was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_activity
      @activity = Activity.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def activity_params
      params.require(:activity).permit(:name, :start_date, :completion_date, :start_time, :completion_time, :place, :quota, :description, :group_id, :exclusiveness)
    end
end
